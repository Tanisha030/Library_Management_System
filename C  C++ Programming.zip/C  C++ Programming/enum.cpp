#include<iostream>

using namespace std;

enum week{sun=5,mon,tue,wed,thurs,fri,sat};
int main()
{
   enum week day1,day2;
   day1=sun;
   day2=fri;
   cout<<day1<<endl;
   cout<<day2<<endl;

}
