#include<iostream>

using namespace std;
int main()
{
    int i=30;
    do
    {
        cout<<i<<endl;
        i-=3;
    }while(i>=3);
}
