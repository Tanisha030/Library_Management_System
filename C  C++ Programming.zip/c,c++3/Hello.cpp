#include<iostream>

using namespace std;

int main()
{
    int a=20;
    float b=20.123f;
    char c='c';
    double d=20.234;
    cout.precision(5);
    cout<<a<<endl;
    cout<<b<<endl;
    cout<<c<<endl;
    cout<<d<<endl;
}
