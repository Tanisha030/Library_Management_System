#include<iostream>

using namespace std;

int main()
{
    int i;
    for(i=3;i<=30;i+=3)
    {
        cout<<i<<endl;
    }

}
