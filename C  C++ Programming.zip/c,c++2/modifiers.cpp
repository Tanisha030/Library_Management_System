#include<iostream>

using namespace std;
class student
{
    protected:
    int a;
};


int main()
{
    student s1;
    s1.a=10;
    cout<<s1.a;
}
