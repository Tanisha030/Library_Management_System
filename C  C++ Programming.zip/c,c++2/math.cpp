#include<iostream>
#include<cmath>

using namespace std;

enum week{sun,mon,tue,wed,thurs,fri,sat};

int main()
{
    enum week day;
    day=sun;
    cout<<day;
}
