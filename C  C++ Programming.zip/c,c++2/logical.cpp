#include<iostream>

using namespace std;

int main()
{
    int a=12;
    a%=5; // a=a%5;
    cout<<a;

}
