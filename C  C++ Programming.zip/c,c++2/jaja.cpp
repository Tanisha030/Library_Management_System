#include<iostream>
using namespace std;

int main()
{
    int a[3][2]={{1,2},{2,3},{3,4}};
    cout<<a[1][1];
    cout<<a[2][1];
}
