#include<iostream>
#include<cmath>

using namespace std;

int main()
{
    int x=1.5,y=3.5,z=2,p=-35;
    cout<<sin(x)<<endl;
    cout<<cos(x)<<endl;
    cout<<tan(x)<<endl;
    cout<<min(x,y)<<endl;
    cout<<max(x,y)<<endl;
    cout<<ceil(x)<<endl;
    cout<<floor(x)<<endl;
    cout<<pow(z,2)<<endl;
    cout<<abs(p)<<endl;
    cout<<sqrt(64)<<endl;

}
