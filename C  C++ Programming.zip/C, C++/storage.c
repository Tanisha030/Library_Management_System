#include<iostream>
using namespace std;
int main()
{
    auto int x;
    x=10;
    cout<<x;
}
