#include<iostream>

using namespace std;

int main()
{
    int a=2,c;
    c=--a;
    cout<<c;

}
