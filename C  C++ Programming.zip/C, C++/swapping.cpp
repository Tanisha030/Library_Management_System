#include<iostream>

using namespace std;

int main()
{
    int a=10,b=20,c;
    cout<<"Enter two numbers"<<endl;
    c=a;
    cout<<a;
    a=b;
    b=c;
    cout<<"swapping value is  : "<<a<<" "<<b;
}
