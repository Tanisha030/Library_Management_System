#include<iostream>
#include<cstring>

using namespace std;

int main()
{
    char name[20];
    cin.getline(name,20);
    cout<<name;
}
