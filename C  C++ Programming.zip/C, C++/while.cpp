#include<iostream>

using namespace std;
int main()
{
    int i=30;
    while(i>=3)
    {
        cout<<i<<endl;
        i-=3;//30  i=i-3
    }

}
