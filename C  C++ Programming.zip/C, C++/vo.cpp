#include<iostream>
using namespace std;
int main()
{
    char c;
    cin>>c;
    switch(c)
    {
    case 'a':
        cout<<"vowel"<<endl;
        break;
    default:
        cout<<"Consonent"<<endl;
        break;
    }
}
