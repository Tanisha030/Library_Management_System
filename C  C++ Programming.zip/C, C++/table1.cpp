#include<iostream>

using namespace std;

int main()
{
    int a=2,b=3,c=4,d=5,e=6,f=7,g=8,h=9,k=10;
    for(int i=1;i<=10;i++)
    {
        cout<<a*i<<b*i<<c*i<<d*i<<e*i<<f*i<<g*i<<h*i<<k*i<<endl;
    }

}
