#include<iostream>

using namespace std;

int main()
{
    int i;
    for(i=4;i<=40;i+=4)
    {
        cout<<i<<endl;
    }

}
