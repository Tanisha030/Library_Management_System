#include<iostream>
using namespace std;

int main()
{
    if(cout<<"Hello World")
    {

    }
}
