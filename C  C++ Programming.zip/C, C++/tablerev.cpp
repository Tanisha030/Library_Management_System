#include<iostream>

using namespace std;

int main()
{
    int a=0,b=0,c=0,d=0,e=0,f=0,g=0,h=0,j=0,i;
    for(i=1;i<10;i++)
    {
        cout<<a+=2<<endl;
    }

}
