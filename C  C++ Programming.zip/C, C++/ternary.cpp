#include<iostream>

using namespace std;

int main()
{
    int age;
    cout<<"Enter your age"<<endl;
    cin>>age;
    age>18?cout<<"You are eligible for vote":cout<<"You are not eligible for vote"<<endl;
}
