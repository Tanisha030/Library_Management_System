#include<iostream>

using namespace std;

int main()
{
    int a=0,b=0,c=0;
    for(int i=0;i<=10;i++)
    {
        cout<<i<<endl;
    }

}

